﻿using System;

namespace OOP3_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first file you will like to compare."); // The programme will print of this line for the user the input the first file
            string file1name = Console.ReadLine(); // The file will be read as a string
            Console.WriteLine("Enter the second file you will like to compare.");// The programme will print of the liine for the user to input the second file
            string file2name = Console.ReadLine();// The second file will read as a string


            string[] file1 = System.IO.File.ReadAllText(file1name + ".txt").Split('\n'); // The system will read each line of the first file 
            string[] file2 = System.IO.File.ReadAllText(file2name + ".txt").Split('\n');// The system will read each line of the second file
            if (file1.Length != file2.Length) // The system will compare the the lengths of the two files 
                Console.WriteLine("These files are not the same."); // if the lengths do not match them, the programme will output this message
            bool data = false;
            for (int i = 0; i < file2.Length - 1; i++) // Coomapres every line of the files 
            {
                if (file1[i] != file2[i])
                {
                    data = true;
                }
            }
            if (data == true)
            {
                Console.WriteLine("These files are not the same"); // if the line amount are not the same the system will output this message

            }
            else
            {
                Console.WriteLine("These files are the same."); // else if the line amount are the same, this message will be displayed 
            }



        }
    }
}
